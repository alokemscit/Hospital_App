import 'package:flutter/material.dart';


const appColorLogo = Color(0xFF086fb8);
const appColorLogoDeep = Color(0xFF0c6cbc);
const appColorPista = Color(0xFFe3f1ea);
const appColorGray200 = Color(0xFFEEEEEE);
const appColorGrayLight = Color(0xFFFAFAFA);
const appColorGrayDark = Color(0xFF757575);
const appColorIndigoA100 = Color(0xFF8C9EFF);

const kSecondaryColor = Color(0xFFF5F6FC);
const kBgLightColor = Color(0xFFF2F4FC);
const kBgDarkColor = Color(0xFFEBEDFA);

