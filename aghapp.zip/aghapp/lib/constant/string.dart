const appName = "Asgar Ali Hospita";
const appFontMuli = "Muli";
const appDocImageUrl = 'https://www.asgaralihospital.com/storage/';
