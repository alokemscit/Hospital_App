export 'package:asgar_ali_hospital/constant/color.dart';
export 'package:asgar_ali_hospital/constant/string.dart';
export 'package:asgar_ali_hospital/constant/properties.dart';
export 'package:flutter/material.dart';
export 'package:velocity_x/velocity_x.dart';



