class ModelUser {
  String? hcn;
  String? name;
  String? mob;
  String? bg;
  String? sex;
  String? dob;
  String? img;
  ModelUser({this.hcn,this.bg,this.dob,this.img,this.mob,this.name,this.sex});
}
