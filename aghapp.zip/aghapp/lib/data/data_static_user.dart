 

import 'package:asgar_ali_hospital/constant/const.dart';

import '../common_model/model_mysql_doctor.dart';

 

class DataStaticUser {
  static String name = '';
  static String hcn = '';
  static String mob = '';
   static String dob = '';
   static String bg = '';
    static String gender = '';
   static Image? img = null;

 // Uint8List? img =null ;//await DataStaticUser.img.toByteData();

static List<ModelMySqlDoctor> doc_list=[];

}
