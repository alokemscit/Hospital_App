package com.aghapp.ehealth.aghapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
